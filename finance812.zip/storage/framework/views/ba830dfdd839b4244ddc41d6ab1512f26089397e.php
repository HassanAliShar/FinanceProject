<?php $__env->startSection('pagesection'); ?>
<div class="container">
    <div class="subheader">
        <h1 class="subheader-title">
            <i class='subheader-icon fal fa-table'></i>Manage Borrower
        </h1>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <div class="panel-hdr">
                    <h2>
                        Borrowers <span class="fw-300"><i>data</i></span>
                    </h2>
                    <div class="panel-toolbar">
                        <button class="btn btn-panel" data-action="panel-collapse" data-toggle="tooltip" data-offset="0,10" data-original-title="Collapse"></button>
                        <button class="btn btn-panel" data-action="panel-fullscreen" data-toggle="tooltip" data-offset="0,10" data-original-title="Fullscreen"></button>
                        <button class="btn btn-panel" data-action="panel-close" data-toggle="tooltip" data-offset="0,10" data-original-title="Close"></button>
                    </div>
                </div>
                <div class="panel-container show">
                    <div class="panel-content">
                        <!-- datatable start -->
                       <table class="table table-bordered table-hover table-striped w-100" id="dt-basic-example3">
                        <thead>
                            <tr>
                                <th>name</th>
                                <th>internal_number</th>
                                <th>identity_no</th>
                                <th>identity_type</th>
                                <th>nationality</th>
                                <th>place_of_birth</th>
                                <th>dob</th>
                                <th>last_education</th>
                                <th>mother_maiden</th>
                                <th>surveyor</th>
                                <th>partner_spouse</th>
                                <th>partner_spouse_identity_number</th>
                                <th>partner_spouse_contact_number</th>
                                <th>partner_spouse_domicile_address</th>
                                <th>marriage_status</th>
                                <th>family_card_number</th>
                                <th>home_number</th>
                                <th>mobile_number</th>
                                <th>office_number</th>
                                <th>domicile_status</th>
                                <th>email</th>
                                <th>status</th>
                                <th>tax_identity_no</th>
                                <th>borrower_type</th>
                                <th>person_in_contact</th>
                                <th>reference</th>
                                <th>identity_address</th>
                                <th>domicile_address</th>
                                <th>office_address</th>
                                <th>occupation</th>
                                <th>line_of_business</th>
                                <th>business_experience</th>
                                <th>business_capital</th>
                                <th>annual_income</th>
                                <th>other_income</th>
                                <th>joint_income</th>
                                <th>total_income</th>
                                <th>living_expenses</th>
                                <th>business_expenses</th>
                                <th>other_expenses</th>
                                <th>other_loan</th>
                                <th>net_cash_flow</th>
                                <th>total_assets</th>
                                <th>other_lenders</th>
                                <th>bank_account</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->internal_number); ?></td>
                                    <td><?php echo e($item->identity_no); ?></td>
                                    <td><?php echo e($item->identity_type); ?></td>
                                    <td><?php echo e($item->nationality); ?></td>
                                    <td><?php echo e($item->place_of_birth); ?></td>
                                    <td><?php echo e($item->dob); ?></td>
                                    <td><?php echo e($item->last_education); ?></td>
                                    <td><?php echo e($item->mother_maiden); ?></td>
                                    <td><?php echo e($item->surveyor); ?></td>
                                    <td><?php echo e($item->partner_spouse); ?></td>
                                    <td><?php echo e($item->partner_spouse_identity_number); ?></td>
                                    <td><?php echo e($item->partner_spouse_contact_number); ?></td>
                                    <td><?php echo e($item->partner_spouse_domicile_address); ?></td>
                                    <td><?php echo e($item->marriage_status); ?></td>
                                    <td><?php echo e($item->family_card_number); ?></td>
                                    <td><?php echo e($item->home_number); ?></td>
                                    <td><?php echo e($item->mobile_number); ?></td>
                                    <td><?php echo e($item->office_number); ?></td>
                                    <td><?php echo e($item->domicile_status); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($item->status); ?></td>
                                    <td><?php echo e($item->tax_identity_no); ?></td>
                                    <td><?php echo e($item->borrower_type); ?></td>
                                    <td><?php echo e($item->person_in_contact); ?></td>
                                    <td><?php echo e($item->reference); ?></td>
                                    <td><?php echo e($item->identity_address); ?></td>
                                    <td><?php echo e($item->domicile_address); ?></td>
                                    <td><?php echo e($item->office_address); ?></td>
                                    <td><?php echo e($item->occupation); ?></td>
                                    <td><?php echo e($item->line_of_business); ?></td>
                                    <td><?php echo e($item->business_experience); ?></td>
                                    <td><?php echo e($item->business_capital); ?></td>
                                    <td><?php echo e($item->annual_income); ?></td>
                                    <td><?php echo e($item->other_income); ?></td>
                                    <td><?php echo e($item->joint_income); ?></td>
                                    <td><?php echo e($item->total_income); ?></td>
                                    <td><?php echo e($item->living_expenses); ?></td>
                                    <td><?php echo e($item->business_expenses); ?></td>
                                    <td><?php echo e($item->other_expenses); ?></td>
                                    <td><?php echo e($item->other_loan); ?></td>
                                    <td><?php echo e($item->net_cash_flow); ?></td>
                                    <td><?php echo e($item->total_assets); ?></td>
                                    <td><?php echo e($item->other_lenders); ?></td>
                                    <td><?php echo e($item->bank_account); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('staff.view.borrower',$item->id)); ?>" class="btn btn-sm btn-primary">View</a>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <!-- datatable end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\Desktop\Safe Car\new_app\resources\views/staff/borrowers.blade.php ENDPATH**/ ?>