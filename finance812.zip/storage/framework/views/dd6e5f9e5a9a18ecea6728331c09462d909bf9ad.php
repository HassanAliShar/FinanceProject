







<script src="<?php echo e(asset('js/datagrid/datatables/datatables.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('js/datagrid/datatables/datatables.export.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
<script src="<?php echo e(asset('js/notifications/toastr/toastr.js')); ?>"></script>




<?php /**PATH C:\Users\Hp\Desktop\Safe Car\new_app\resources\views/includes/page_scripts.blade.php ENDPATH**/ ?>