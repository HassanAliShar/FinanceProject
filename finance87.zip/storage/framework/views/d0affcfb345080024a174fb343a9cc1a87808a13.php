<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <div id="app">
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(Session::has('error')): ?>
        <script>
            toastr.error("<?php echo e(Session::get('error')); ?>");
        </script>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <script>
            toastr.success("<?php echo e(Session::get('success')); ?>");
        </script>
    <?php endif; ?>


</body>
</html>
<?php /**PATH C:\Users\Hp\Desktop\Safe Car\new_app\resources\views/layouts/app.blade.php ENDPATH**/ ?>