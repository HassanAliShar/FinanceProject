<?php

namespace App\Http\Controllers;

use App\Models\LoanSchedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LaonScheduleController extends Controller
{
    public function index(){

    }
    public function create($id){
        return view('director.loan.loan-schdule',['id'=>$id]);
    }

    public function store(Request $request,$id){
        // return $request;
        DB::beginTransaction();
        $schdule = new LoanSchedule();
        $schdule->loan_id = $id;
        $schdule->principal_payment = $request->principal_payment;
        $schdule->interest_payment = $request->interest_payment;
        $schdule->expected_payment = $request->expected_payment;
        $schdule->expected_payment_date = $request->expected_payment_date;
        if($schdule->save()){
            DB::commit();
            return redirect()->back()->with('success','Loan Schdule Added Successfully');
        }
        else{
            DB::rollBack();
            return redirect()->back()->with('error','Loan Schdule Not Added');
        }
    }

    public function destory($id){
        $schdule = LoanSchedule::find($id);
        if($schdule->delete()){
            return redirect()->back()->with('success','Loan Schdule Deleted Successfully');
        }
        else{
            return redirect()->back()->with('error','Loan Schdule Not Deleted');
        }
    }
}
