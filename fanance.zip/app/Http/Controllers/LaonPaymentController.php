<?php

namespace App\Http\Controllers;

use App\Models\LoanPayment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LaonPaymentController extends Controller
{
    public function index(){

    }
    public function create($id){
        return view('director.loan.payment.add',['id'=>$id]);
    }

    public function store(Request $request,$id){
        // return $request;
        DB::beginTransaction();
        $payment = new LoanPayment();
        $payment->loan_id = $id;
        $payment->payment_amount = $request->payment_amount;
        $payment->payment_date = $request->payment_date;
        $payment->payment_note = $request->payment_note;
        if($payment->save()){
            DB::commit();
            return redirect()->back()->with('success','Loan Payment Added Successfully');
        }
        else{
            DB::rollBack();
            return redirect()->back()->with('error','Loan Payment Not Added');
        }
    }

    public function destory($id){
        $payment = LoanPayment::find($id);

        if($payment->delete()){
            return redirect()->back()->with('success','Loan Payment Deleted Successfully');
        }
        else{
            return redirect()->back()->with('error','Loan Payment Not Deleted');
        }
    }
}
