<?php $__env->startSection('pagesection'); ?>
<div class="container">
    <div class="subheader">
        <h1 class="subheader-title">
            <i class='subheader-icon fal fa-table'></i> Dashboard
        </h1>
        <a href="" class="btn btn-primary waves-effect waves-themed text-white"><i
                class="fal fa-plus-circle"></i> Create
        </a>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <!-- datatable start -->
                <table class="table table-bordered table-hover table-striped w-100">
                    <thead>
                        <tr>
                            <th>Sno</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Active</th>
                        </tr>
                    </thead>
                    <tbody>
                        

                            <tr>
                                
                            </tr>

                        
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Sno</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Active</th>
                        </tr>
                    </tfoot>
                </table>
                <!-- datatable end -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\Desktop\Safe Car\new_app\resources\views/director/dashboard.blade.php ENDPATH**/ ?>