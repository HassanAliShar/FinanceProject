<?php $__env->startSection('pagesection'); ?>
<div class="container">
    <div class="subheader">
        <h1 class="subheader-title">
            <i class='subheader-icon fal fa-table'></i> View Borrower
        </h1>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <div class="panel-hdr">
                    <h2>
                        Borrower <span class="fw-300"><i>info</i></span>
                    </h2>
                    <div class="panel-toolbar">
                        <button class="btn btn-panel" data-action="panel-collapse" data-toggle="tooltip" data-offset="0,10" data-original-title="Collapse"></button>
                        <button class="btn btn-panel" data-action="panel-fullscreen" data-toggle="tooltip" data-offset="0,10" data-original-title="Fullscreen"></button>
                        <button class="btn btn-panel" data-action="panel-close" data-toggle="tooltip" data-offset="0,10" data-original-title="Close"></button>
                    </div>
                </div>
                <div class="panel-container show">
                    <div class="panel-content">
                        <div class="card-body">
                            <form>
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                                    <div class="col-md-6">
                                        <input id="name" type="text" readonly class="form-control" placeholder="Full Name" name="name" value="<?php echo e($data->name); ?>" required autocomplete="name" autofocus>


                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="identity_no" class="col-md-4 col-form-label text-md-right">Identity No</label>

                                    <div class="col-md-6">
                                        <input id="identity_no" type="text" readonly class="form-control" placeholder="Identity No" name="identity_no" value="<?php echo e($data->identity_no); ?>" required autocomplete="identity_no">

                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="identity_type" class="col-md-4 col-form-label text-md-right">Identity Type</label>

                                    <div class="col-md-6">
                                        <input id="identity_type" type="text" readonly class="form-control" placeholder="Identity Type" name="identity_type" value="<?php echo e($data->identity_type); ?>" required autocomplete="identity_type">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="nationality" class="col-md-4 col-form-label text-md-right">Nationality</label>

                                    <div class="col-md-6">
                                        <input id="nationality" type="text" readonly class="form-control" placeholder="Nationality" name="nationality" value="<?php echo e($data->nationality); ?>" required autocomplete="nationality">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="dob" class="col-md-4 col-form-label text-md-right">Date Of Birth</label>

                                    <div class="col-md-6">
                                        <input id="dob" type="date" readonly class="form-control" name="dob" value="<?php echo e($data->dob); ?>" required autocomplete="dob">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="tax_identity_no" class="col-md-4 col-form-label text-md-right">Tax Identity No</label>

                                    <div class="col-md-6">
                                        <input id="tax_identity_no" readonly type="text" class="form-control" placeholder="Tax Identity No" name="tax_identity_no" value="<?php echo e($data->tax_identity_no); ?>" required autocomplete="tax_identity_no">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="borrower_type" class="col-md-4 col-form-label text-md-right">Borrower Type</label>

                                    <div class="col-md-6">
                                        <input id="borrower_type" type="text" readonly class="form-control" placeholder="Borrower Type" name="borrower_type" value="<?php echo e($data->borrower_type); ?>" required autocomplete="borrower_type">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="person_in_contact" class="col-md-4 col-form-label text-md-right">Person in Contact</label>

                                    <div class="col-md-6">
                                        <input id="person_in_contact" type="text" readonly class="form-control" placeholder="Person in Contact" name="person_in_contact" value="<?php echo e($data->person_in_contact); ?>" required autocomplete="person_in_contact">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="reference" class="col-md-4 col-form-label text-md-right">Reference</label>

                                    <div class="col-md-6">
                                        <input id="reference" type="text" readonly class="form-control" placeholder="Reference" name="reference" value="<?php echo e($data->reference); ?>" required autocomplete="reference">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="identity_address" class="col-md-4 col-form-label text-md-right">Identity Address</label>

                                    <div class="col-md-6">
                                        <input id="identity_address" type="text" readonly class="form-control" placeholder="Identity Address" name="identity_address" value="<?php echo e($data->identity_address); ?>" required autocomplete="identity_address">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="domicile_address" class="col-md-4 col-form-label text-md-right">Domicile Address</label>

                                    <div class="col-md-6">
                                        <input id="domicile_address" type="text" readonly class="form-control" placeholder="Domicile Address" name="domicile_address" value="<?php echo e($data->domicile_address); ?>" required autocomplete="domicile_address">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="office_address" class="col-md-4 col-form-label text-md-right">Office Address</label>

                                    <div class="col-md-6">
                                        <input id="office_address" type="text" readonly class="form-control" placeholder="Office Address" name="office_address" value="<?php echo e($data->office_address); ?>" required autocomplete="office_address">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="occupation" class="col-md-4 col-form-label text-md-right">Occupation</label>

                                    <div class="col-md-6">
                                        <input id="occupation" type="text" readonly class="form-control" placeholder="Occupation" name="occupation" value="<?php echo e($data->occupation); ?>" required autocomplete="occupation">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="line_of_business" class="col-md-4 col-form-label text-md-right">Line of Business</label>

                                    <div class="col-md-6">
                                        <input id="line_of_business" type="text" readonly class="form-control" placeholder="Line of Business" name="line_of_business" value="<?php echo e($data->line_of_business); ?>" required autocomplete="line_of_business">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="bank_account" class="col-md-4 col-form-label text-md-right">Bank Account</label>

                                    <div class="col-md-6">
                                        <input id="bank_account" type="text" readonly class="form-control" placeholder="Bank Account" name="bank_account" value="<?php echo e($data->bank_account); ?>" required autocomplete="bank_account">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\Desktop\Safe Car\new_app\resources\views/manager/Borrower/view.blade.php ENDPATH**/ ?>