-- MariaDB dump 10.17  Distrib 10.4.11-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: finance
-- ------------------------------------------------------
-- Server version	10.4.11-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `borrower_approvals`
--

DROP TABLE IF EXISTS `borrower_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrower_approvals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `borrower_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identity_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identity_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nationality` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `tax_identity_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `person_in_contact` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identity_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `domicile_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `office_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `occupation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `line_of_business` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_account` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `borrower_approvals_user_id_foreign` (`user_id`),
  CONSTRAINT `borrower_approvals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrower_approvals`
--

LOCK TABLES `borrower_approvals` WRITE;
/*!40000 ALTER TABLE `borrower_approvals` DISABLE KEYS */;
/*!40000 ALTER TABLE `borrower_approvals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrower_field_approvals`
--

DROP TABLE IF EXISTS `borrower_field_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrower_field_approvals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_approval_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `borrower_field_approvals_borrower_approval_id_foreign` (`borrower_approval_id`),
  CONSTRAINT `borrower_field_approvals_borrower_approval_id_foreign` FOREIGN KEY (`borrower_approval_id`) REFERENCES `borrower_approvals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrower_field_approvals`
--

LOCK TABLES `borrower_field_approvals` WRITE;
/*!40000 ALTER TABLE `borrower_field_approvals` DISABLE KEYS */;
/*!40000 ALTER TABLE `borrower_field_approvals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrower_fields`
--

DROP TABLE IF EXISTS `borrower_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrower_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `borrower_fields_borrower_id_foreign` (`borrower_id`),
  CONSTRAINT `borrower_fields_borrower_id_foreign` FOREIGN KEY (`borrower_id`) REFERENCES `borrowers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrower_fields`
--

LOCK TABLES `borrower_fields` WRITE;
/*!40000 ALTER TABLE `borrower_fields` DISABLE KEYS */;
INSERT INTO `borrower_fields` VALUES (1,'cnic','12345',1,'2021-08-03 01:01:03','2021-08-03 01:01:03');
/*!40000 ALTER TABLE `borrower_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrower_file_approvals`
--

DROP TABLE IF EXISTS `borrower_file_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrower_file_approvals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_approval_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `borrower_file_approvals_borrower_approval_id_foreign` (`borrower_approval_id`),
  CONSTRAINT `borrower_file_approvals_borrower_approval_id_foreign` FOREIGN KEY (`borrower_approval_id`) REFERENCES `borrower_approvals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrower_file_approvals`
--

LOCK TABLES `borrower_file_approvals` WRITE;
/*!40000 ALTER TABLE `borrower_file_approvals` DISABLE KEYS */;
/*!40000 ALTER TABLE `borrower_file_approvals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrower_files`
--

DROP TABLE IF EXISTS `borrower_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrower_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `borrower_files_borrower_id_foreign` (`borrower_id`),
  CONSTRAINT `borrower_files_borrower_id_foreign` FOREIGN KEY (`borrower_id`) REFERENCES `borrowers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrower_files`
--

LOCK TABLES `borrower_files` WRITE;
/*!40000 ALTER TABLE `borrower_files` DISABLE KEYS */;
INSERT INTO `borrower_files` VALUES (1,'image','KnNMl95eY2SyVA1h7ksFV4OZhMfQWS.jpg',1,'2021-08-03 01:01:03','2021-08-03 01:01:03');
/*!40000 ALTER TABLE `borrower_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrowers`
--

DROP TABLE IF EXISTS `borrowers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrowers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identity_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identity_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nationality` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_identity_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `person_in_contact` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identity_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `domicile_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `office_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `occupation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `line_of_business` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_account` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `borrowers_created_by_foreign` (`created_by`),
  CONSTRAINT `borrowers_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrowers`
--

LOCK TABLES `borrowers` WRITE;
/*!40000 ALTER TABLE `borrowers` DISABLE KEYS */;
INSERT INTO `borrowers` VALUES (1,'Hassan Ali','345','rfwe','pakistani','2021-08-03','Approved','45','data','Sajid','Ameer','Karachi','Nawabshah','wp coders','developer','Software','03011000001100',0,1,'2021-08-03 01:01:03','2021-08-03 01:01:03');
/*!40000 ALTER TABLE `borrowers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_approvels`
--

DROP TABLE IF EXISTS `loan_approvels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_approvels` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `borrower_id` bigint(20) unsigned NOT NULL,
  `loan_id` bigint(20) unsigned DEFAULT NULL,
  `lender_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `legal_loan_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `interest_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `interest_rate` decimal(10,2) NOT NULL,
  `initial_amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenor` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_period` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provision_charges` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `insurance_charges` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notary_charges` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collateral` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `bank_account` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_approvels_borrower_id_foreign` (`borrower_id`),
  KEY `loan_approvels_user_id_foreign` (`user_id`),
  CONSTRAINT `loan_approvels_borrower_id_foreign` FOREIGN KEY (`borrower_id`) REFERENCES `borrowers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `loan_approvels_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_approvels`
--

LOCK TABLES `loan_approvels` WRITE;
/*!40000 ALTER TABLE `loan_approvels` DISABLE KEYS */;
INSERT INTO `loan_approvels` VALUES (2,1,NULL,'Hassan Ali','0001','Data','2021-08-03','2021-08-31','percentage',2321.00,'12000','1200','4 months','2%','1%','2%','sd',2,'0100021101101000','Insert','Approved','2021-08-03 01:46:10','2021-08-03 02:10:25'),(3,1,2,'Hassan Ali','0001','Data','2021-08-03','2021-08-31','percentage',400000.00,'12000','1200','4 months','2%','1%','2%','sd',2,'0100021101101000','Update','Pending','2021-08-03 01:53:47','2021-08-03 01:53:47');
/*!40000 ALTER TABLE `loan_approvels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_field_approvels`
--

DROP TABLE IF EXISTS `loan_field_approvels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_field_approvels` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_approvel_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_field_approvels_loan_approvel_id_foreign` (`loan_approvel_id`),
  CONSTRAINT `loan_field_approvels_loan_approvel_id_foreign` FOREIGN KEY (`loan_approvel_id`) REFERENCES `loan_approvels` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_field_approvels`
--

LOCK TABLES `loan_field_approvels` WRITE;
/*!40000 ALTER TABLE `loan_field_approvels` DISABLE KEYS */;
INSERT INTO `loan_field_approvels` VALUES (1,'cnic','021001000101',2,'2021-08-03 01:46:10','2021-08-03 01:46:10'),(2,'cnic','03062882501',3,'2021-08-03 01:53:47','2021-08-03 01:53:47'),(3,'father_name','Ali',3,'2021-08-03 01:53:47','2021-08-03 01:53:47');
/*!40000 ALTER TABLE `loan_field_approvels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_fields`
--

DROP TABLE IF EXISTS `loan_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_fields_loan_id_foreign` (`loan_id`),
  CONSTRAINT `loan_fields_loan_id_foreign` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_fields`
--

LOCK TABLES `loan_fields` WRITE;
/*!40000 ALTER TABLE `loan_fields` DISABLE KEYS */;
INSERT INTO `loan_fields` VALUES (1,'cnic','03062882501',2,'2021-08-03 01:05:32','2021-08-03 01:05:32'),(2,'cnic','021001000101',3,'2021-08-03 02:10:25','2021-08-03 02:10:25');
/*!40000 ALTER TABLE `loan_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_file_approvels`
--

DROP TABLE IF EXISTS `loan_file_approvels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_file_approvels` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_approvel_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_file_approvels_loan_approvel_id_foreign` (`loan_approvel_id`),
  CONSTRAINT `loan_file_approvels_loan_approvel_id_foreign` FOREIGN KEY (`loan_approvel_id`) REFERENCES `loan_approvels` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_file_approvels`
--

LOCK TABLES `loan_file_approvels` WRITE;
/*!40000 ALTER TABLE `loan_file_approvels` DISABLE KEYS */;
INSERT INTO `loan_file_approvels` VALUES (1,'image','vIjzFIDCAjsUMCLC9q8ejkGcDZSnGh.jpg',2,'2021-08-03 01:46:10','2021-08-03 01:46:10');
/*!40000 ALTER TABLE `loan_file_approvels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_files`
--

DROP TABLE IF EXISTS `loan_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_files_loan_id_foreign` (`loan_id`),
  CONSTRAINT `loan_files_loan_id_foreign` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_files`
--

LOCK TABLES `loan_files` WRITE;
/*!40000 ALTER TABLE `loan_files` DISABLE KEYS */;
INSERT INTO `loan_files` VALUES (1,'image','tJMbb7gqGrwhKO0dB3UmqFcLrnv5Mo.jpg',2,'2021-08-03 01:05:32','2021-08-03 01:05:32'),(2,'image','vIjzFIDCAjsUMCLC9q8ejkGcDZSnGh.jpg',3,'2021-08-03 02:10:25','2021-08-03 02:10:25');
/*!40000 ALTER TABLE `loan_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_payment_approvels`
--

DROP TABLE IF EXISTS `loan_payment_approvels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_payment_approvels` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `loan_id` bigint(20) unsigned NOT NULL,
  `payment_id` bigint(20) unsigned DEFAULT NULL,
  `payment_amount` decimal(10,2) NOT NULL,
  `interest_amount` decimal(10,2) DEFAULT NULL,
  `payment_date` date NOT NULL,
  `payment_note` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_payment_approvels_loan_id_foreign` (`loan_id`),
  KEY `loan_payment_approvels_user_id_foreign` (`user_id`),
  CONSTRAINT `loan_payment_approvels_loan_id_foreign` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `loan_payment_approvels_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_payment_approvels`
--

LOCK TABLES `loan_payment_approvels` WRITE;
/*!40000 ALTER TABLE `loan_payment_approvels` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_payment_approvels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_payments`
--

DROP TABLE IF EXISTS `loan_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `loan_id` bigint(20) unsigned NOT NULL,
  `payment_amount` decimal(10,2) NOT NULL,
  `interest_amount` decimal(10,2) DEFAULT NULL,
  `payment_date` date NOT NULL,
  `payment_note` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_payments_loan_id_foreign` (`loan_id`),
  CONSTRAINT `loan_payments_loan_id_foreign` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_payments`
--

LOCK TABLES `loan_payments` WRITE;
/*!40000 ALTER TABLE `loan_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_schdule_approvels`
--

DROP TABLE IF EXISTS `loan_schdule_approvels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_schdule_approvels` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `loan_id` bigint(20) unsigned NOT NULL,
  `schdule_id` bigint(20) unsigned DEFAULT NULL,
  `principal_payment` decimal(20,2) NOT NULL,
  `interest_payment` decimal(20,2) NOT NULL,
  `expected_payment` decimal(20,2) NOT NULL,
  `expected_payment_date` date NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_schdule_approvels_loan_id_foreign` (`loan_id`),
  KEY `loan_schdule_approvels_user_id_foreign` (`user_id`),
  CONSTRAINT `loan_schdule_approvels_loan_id_foreign` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `loan_schdule_approvels_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_schdule_approvels`
--

LOCK TABLES `loan_schdule_approvels` WRITE;
/*!40000 ALTER TABLE `loan_schdule_approvels` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_schdule_approvels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_schedules`
--

DROP TABLE IF EXISTS `loan_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `loan_id` bigint(20) unsigned NOT NULL,
  `principal_payment` decimal(20,2) NOT NULL,
  `interest_payment` decimal(20,2) NOT NULL,
  `expected_payment` decimal(20,2) NOT NULL,
  `expected_payment_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loan_schedules_loan_id_foreign` (`loan_id`),
  CONSTRAINT `loan_schedules_loan_id_foreign` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_schedules`
--

LOCK TABLES `loan_schedules` WRITE;
/*!40000 ALTER TABLE `loan_schedules` DISABLE KEYS */;
INSERT INTO `loan_schedules` VALUES (1,2,200.00,10.00,5000.00,'2021-08-11','2021-08-03 07:02:40','2021-08-03 07:02:40'),(2,2,200.00,20.00,1212.00,'2021-08-19','2021-08-03 07:31:33','2021-08-03 07:31:33');
/*!40000 ALTER TABLE `loan_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loans`
--

DROP TABLE IF EXISTS `loans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `borrower_id` bigint(20) unsigned NOT NULL,
  `lender_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `legal_loan_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `interest_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `interest_rate` decimal(10,2) NOT NULL,
  `initial_amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenor` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_period` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provision_charges` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `insurance_charges` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notary_charges` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collateral` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_account` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loans_borrower_id_foreign` (`borrower_id`),
  CONSTRAINT `loans_borrower_id_foreign` FOREIGN KEY (`borrower_id`) REFERENCES `borrowers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loans`
--

LOCK TABLES `loans` WRITE;
/*!40000 ALTER TABLE `loans` DISABLE KEYS */;
INSERT INTO `loans` VALUES (2,1,'Hassan Ali','0001','Data','2021-08-03','2021-08-31','percentage',400000.00,'12000','1200','4 months','2%','1%','2%','sd','0100021101101000','2021-08-03 01:05:32','2021-08-03 01:05:32'),(3,1,'Hassan Ali','0001','Data','2021-08-03','2021-08-31','percentage',2321.00,'12000','1200','4 months','2%','1%','2%','sd','0100021101101000','2021-08-03 02:10:25','2021-08-03 02:10:25');
/*!40000 ALTER TABLE `loans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2013_07_26_111912_create_roles_table',1),(2,'2014_10_12_000000_create_users_table',1),(3,'2014_10_12_100000_create_password_resets_table',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(6,'2021_07_26_134910_create_borrowers_table',1),(7,'2021_07_27_095905_create_borrower_fields_table',1),(8,'2021_07_27_100013_create_borrower_files_table',1),(9,'2021_07_27_104530_create_borrower_approvals_table',1),(10,'2021_07_27_104538_create_borrower_field_approvals_table',1),(11,'2021_07_27_104548_create_borrower_file_approvals_table',1),(12,'2021_07_30_093246_create_loans_table',1),(13,'2021_07_30_111728_create_loan_schedules_table',1),(14,'2021_07_30_122658_create_loan_payments_table',1),(15,'2021_07_31_111249_create_loan_approvels_table',1),(16,'2021_07_31_111611_create_loan_payment_approvels_table',1),(17,'2021_07_31_111703_create_loan_schdule_approvels_table',1),(18,'2021_08_03_053741_create_loan_fields_table',1),(19,'2021_08_03_053914_create_loan_files_table',1),(20,'2021_08_03_054148_create_loan_field_approvels_table',1),(21,'2021_08_03_054348_create_loan_file_approvels_table',1),(22,'2021_07_26_133126_create_settings_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rights` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Director','*',NULL,NULL),(2,'Manager','*',NULL,NULL),(3,'Staff','*',NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'image','20210803092434.jpg',NULL,'2021-08-03 04:24:34'),(2,'title','MicorFinance',NULL,'2021-08-03 04:13:07'),(3,'welcome','Welcome Dear',NULL,'2021-08-03 04:23:55'),(4,'footer','Copyright 2021',NULL,'2021-08-03 04:24:01');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_foreign` (`role_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Demo Director','director@yopmail.com',NULL,'$2y$10$h3XabWyiyrNIsuJST02zDOWYCCsr9JSnZngdDXu.T3Sy7/RBy/QQS',NULL,1,NULL,NULL),(2,'Demo Manager','manager@yopmail.com',NULL,'$2y$10$EhLZwRU/19aR.mB.zJre3enUS2wKMtLJ4xsvH4YtZF7/apcyCTT2y',NULL,2,NULL,NULL),(3,'Demo Staff','staff@yopmail.com',NULL,'$2y$10$AR551/plLkNIYsHPBQOroOxHDiBJBvDpBYQtJ5V3CEwJW1tyY4tCG',NULL,3,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-03 21:39:22
