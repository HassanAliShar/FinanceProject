<?php

namespace App\Http\Controllers;

use App\Models\Borrower;
use App\Models\Loan;
use App\Models\LoanPayment;
use App\Models\LoanSchedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Broadcast;
use Illuminate\Support\Facades\DB;

class LoanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('director.loan.manage',['data'=>Loan::all()]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('director.loan.add',['data'=>Borrower::all()]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        DB::beginTransaction();
        $loan = new Loan();
        $loan->borrower_id = $request->borrower_id;
        $loan->lender_name = $request->lender_name;
        $loan->legal_loan_id = $request->legal_loan_id;
        $loan->loan_type = $request->loan_type;
        $loan->start_date = $request->start_date;
        $loan->end_date = $request->end_date;
        $loan->interest_type = $request->interest_type;
        $loan->interest_rate = $request->interest_rate;
        $loan->initial_amount = $request->initial_amount;
        $loan->tenor = $request->tenor;
        $loan->payment_period = $request->payment_period;
        $loan->provision_charges = $request->provision_charges;
        $loan->insurance_charges = $request->insurance_charges;
        $loan->notary_charges = $request->notary_charges;
        $loan->collateral = $request->collateral;
        $loan->bank_account = $request->bank_account;

        if($loan->save()){
            DB::commit();
            return redirect()->back()->with('success','Laon Added Successfully');
        }
        else{
            DB::rollBack();
            return redirect()->back()->with('error','Loan Not Added');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show_view($id)
    {
        return view('director.loan.view',['data'=>Loan::find($id),'borrower'=>Borrower::all()]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return view('director.loan.edit',['data'=>Loan::find($id),'borrower'=>Borrower::all()]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        DB::beginTransaction();
        $loan = Loan::find($id);
        $loan->lender_name = $request->lender_name;
        $loan->legal_loan_id = $request->legal_loan_id;
        $loan->loan_type = $request->loan_type;
        $loan->start_date = $request->start_date;
        $loan->end_date = $request->end_date;
        $loan->interest_type = $request->interest_type;
        $loan->interest_rate = $request->interest_rate;
        $loan->initial_amount = $request->initial_amount;
        $loan->tenor = $request->tenor;
        $loan->payment_period = $request->payment_period;
        $loan->provision_charges = $request->provision_charges;
        $loan->insurance_charges = $request->insurance_charges;
        $loan->notary_charges = $request->notary_charges;
        $loan->collateral = $request->collateral;
        $loan->bank_account = $request->bank_account;

        if($loan->save()){
            DB::commit();
            return redirect()->back()->with('success','Laon Updated Successfully');
        }
        else{
            DB::rollBack();
            return redirect()->back()->with('error','Loan Not Updated');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $loan = Loan::find($id);
        if($loan->delete()){
            return redirect()->back()->with('success','Laon Deleted Successfully');
        }
        else{
            return redirect()->back()->with('error','Laon Not Deleted');
        }
    }

    public function schedule($id)
    {
        return view('director.loan.schdule.manage_schdule',['data'=>LoanSchedule::where('loan_id',$id)->get(),'id'=>$id]);
    }

    public function payments($id)
    {
        return view('director.loan.payment.manage',['data'=>LoanPayment::where('loan_id',$id)->get(),'id'=>$id]);
    }
}
