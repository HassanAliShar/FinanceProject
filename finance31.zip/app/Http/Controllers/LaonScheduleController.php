<?php

namespace App\Http\Controllers;

use App\Models\LoanSchedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LaonScheduleController extends Controller
{
    public function index(){

    }
    public function create($id){
        return view('director.loan.schdule.loan-schdule',['id'=>$id]);
    }

    public function store(Request $request,$id){
        // return $request;
        DB::beginTransaction();
        $schdule = new LoanSchedule();
        $schdule->loan_id = $id;
        $schdule->principal_payment = $request->principal_payment;
        $schdule->interest_payment = $request->interest_payment;
        $schdule->expected_payment = $request->expected_payment;
        $schdule->expected_payment_date = $request->expected_payment_date;
        if($schdule->save()){
            DB::commit();
            return redirect()->back()->with('success','Loan Schdule Added Successfully');
        }
        else{
            DB::rollBack();
            return redirect()->back()->with('error','Loan Schdule Not Added');
        }
    }

    public function edit($id){
        return view('director.loan.schdule.edit-schdule',['data'=>LoanSchedule::find($id)]);
    }

    public function update(Request $request,$id){
        DB::beginTransaction();
        $schdule = LoanSchedule::find($id);
        $schdule->principal_payment = $request->principal_payment;
        $schdule->interest_payment = $request->interest_payment;
        $schdule->expected_payment = $request->expected_payment;
        $schdule->expected_payment_date = $request->expected_payment_date;
        if($schdule->save()){
            DB::commit();
            return redirect()->back()->with('success','Loan Schdule Update Successfully');
        }
        else{
            DB::rollBack();
            return redirect()->back()->with('error','Loan Schdule Not Update');
        }
    }

    public function destory($id){
        $schdule = LoanSchedule::find($id);
        if($schdule->delete()){
            return redirect()->back()->with('success','Loan Schdule Deleted Successfully');
        }
        else{
            return redirect()->back()->with('error','Loan Schdule Not Deleted');
        }
    }

    public function show($id){
        return view('director.loan.schdule.view',['data'=>LoanSchedule::find($id)]);
    }
}
