<?php

use App\Models\Role;
use App\Models\User;

function getStaffRoleId(){
    return 3;
}

function getManagerRoleId(){
    return 2;
}

function getDirectorRoleId(){
    return 1;
}



