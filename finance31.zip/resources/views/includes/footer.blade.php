<!-- BEGIN Page Footer -->
<script>
    $(document).ready(function()
    {
        // initialize datatable
        $('#dt-basic-example').dataTable(
        {
            responsive: false,
            buttons: [
                /*{
                    extend:    'colvis',
                    text:      'Column Visibility',
                    titleAttr: 'Col visibility',
                    className: 'mr-sm-3'
                },*/
                {
                    extend: 'pdfHtml5',
                    text: 'PDF',
                    titleAttr: 'Generate PDF',
                    className: 'btn-outline-danger btn-sm mr-1'
                },
                {
                    extend: 'excelHtml5',
                    text: 'Excel',
                    titleAttr: 'Generate Excel',
                    className: 'btn-outline-success btn-sm mr-1'
                },
                {
                    extend: 'csvHtml5',
                    text: 'CSV',
                    titleAttr: 'Generate CSV',
                    className: 'btn-outline-primary btn-sm mr-1'
                },
                {
                    extend: 'print',
                    text: 'Print',
                    titleAttr: 'Print Table',
                    className: 'btn-outline-primary btn-sm'
                }
            ],
            render: function(data, type, full, meta)
            {
                var badge = {
                    1:
                    {
                        'title': 'Pending',
                        'class': 'badge-warning'
                    },
                    2:
                    {
                        'title': 'Delivered',
                        'class': 'badge-success'
                    },
                    3:
                    {
                        'title': 'Canceled',
                        'class': 'badge-secondary'
                    },
                    4:
                    {
                        'title': 'Attempt #1',
                        'class': 'bg-danger-100 text-white'
                    },
                    5:
                    {
                        'title': 'Attempt #2',
                        'class': 'bg-danger-300 text-white'
                    },
                    6:
                    {
                        'title': 'Failed',
                        'class': 'badge-danger'
                    },
                    7:
                    {
                        'title': 'Attention!',
                        'class': 'badge-primary'
                    },
                    8:
                    {
                        'title': 'In Progress',
                        'class': 'badge-success'
                    },
                };
                if (typeof badge[data] === 'undefined')
                {
                    return data;
                }
                return '<span class="badge ' + badge[data].class + ' badge-pill">' + badge[data].title + '</span>';
            }
        });
    });

</script>
<!-- END Page Footer -->
@include('includes.page_scripts')
