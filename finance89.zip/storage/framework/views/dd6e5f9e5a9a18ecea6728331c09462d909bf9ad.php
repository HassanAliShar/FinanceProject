







<script src="<?php echo e(asset('js/datagrid/datatables/datatables.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('js/datagrid/datatables/datatables.export.js')); ?>"></script>
<script src="<?php echo e(asset('js/notifications/toastr/toastr.js')); ?>"></script>




<?php /**PATH C:\Users\Hp\Desktop\Safe Car\new_app\resources\views/includes/page_scripts.blade.php ENDPATH**/ ?>