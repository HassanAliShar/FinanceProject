


<link rel="stylesheet" media="screen, print" href="<?php echo e(asset('css/datagrid/datatables/datatables.bundle.css')); ?>">
<link rel="stylesheet" media="screen, print" href="<?php echo e(asset('css/notifications/toastr/toastr.css')); ?>">
<?php /**PATH C:\Users\Hp\Desktop\Safe Car\new_app\resources\views/includes/page_styles.blade.php ENDPATH**/ ?>