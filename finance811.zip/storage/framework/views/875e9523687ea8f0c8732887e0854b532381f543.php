<?php $__env->startSection('pagesection'); ?>
<div class="container">
    <div class="subheader">
        <h1 class="subheader-title">
            <i class='subheader-icon fal fa-table'></i>Requested Borrower
        </h1>
        <a href="<?php echo e(route('add.b.approve')); ?>" class="btn btn-primary waves-effect waves-themed text-white"><i
            class="fal fa-plus-circle"></i> Add New
        </a>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <div class="panel-hdr">
                    <h2>
                        Borrowers <span class="fw-300"><i>data</i></span>
                    </h2>
                    <div class="panel-toolbar">
                        <button class="btn btn-panel" data-action="panel-collapse" data-toggle="tooltip" data-offset="0,10" data-original-title="Collapse"></button>
                        <button class="btn btn-panel" data-action="panel-fullscreen" data-toggle="tooltip" data-offset="0,10" data-original-title="Fullscreen"></button>
                        <button class="btn btn-panel" data-action="panel-close" data-toggle="tooltip" data-offset="0,10" data-original-title="Close"></button>
                    </div>
                </div>
                <div class="panel-container show">
                    <div class="panel-content">
                        <!-- datatable start -->
                            <table class="table table-bordered table-hover table-striped w-100" id="dt-basic-example">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Identity No</th>
                                        <th>Nationality</th>
                                        <th>Borrower Type</th>
                                        <th>Request for</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td scope="row"><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->identity_no); ?></td>
                                            <td><?php echo e($item->nationality); ?></td>
                                            <td><?php echo e($item->borrower_type); ?></td>
                                            <td><?php echo e($item->type); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('view_requested.borrower',$item->id)); ?>" class="btn btn-sm btn-primary">View</a>
                                                <a href="<?php echo e(route('accept.borrower',$item->id)); ?>" class="btn btn-sm btn-success">Accept</a>
                                                <a href="<?php echo e(route('reject.borrower',$item->id)); ?>" class="btn btn-sm btn-danger">Reject</a>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Name</th>
                                        <th>Identity No</th>
                                        <th>Nationality</th>
                                        <th>Borrower Type</th>
                                        <th>Request for</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                            </table>
                        <!-- datatable end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\Desktop\Safe Car\new_app\resources\views/director/Borrower/index.blade.php ENDPATH**/ ?>