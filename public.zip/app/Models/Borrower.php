<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Borrower extends Model
{
    use HasFactory;

    public function fields()
    {
        return $this->hasMany(BorrowerField::class);
    }

    public function files()
    {
        return $this->hasMany(BorrowerFile::class);
    }

}
