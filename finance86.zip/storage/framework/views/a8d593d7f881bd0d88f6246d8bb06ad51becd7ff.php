<?php $__env->startSection('pagesection'); ?>
<div class="container">
    <div class="subheader">
        <h1 class="subheader-title">
            <i class='subheader-icon fal fa-table'></i> Manage Loan Sechdule
        </h1>
        <a href="<?php echo e(route('add.schdule',$id)); ?>" class="btn btn-primary waves-effect waves-themed text-white"><i
            class="fal fa-plus-circle"></i> Add Loan Sechdule
        </a>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <div class="panel-hdr">
                    <h2>
                        Loan Schdule <span class="fw-300"><i>info</i></span>
                    </h2>
                    <div class="panel-toolbar">
                        <button class="btn btn-panel" data-action="panel-collapse" data-toggle="tooltip" data-offset="0,10" data-original-title="Collapse"></button>
                        <button class="btn btn-panel" data-action="panel-fullscreen" data-toggle="tooltip" data-offset="0,10" data-original-title="Fullscreen"></button>
                        <button class="btn btn-panel" data-action="panel-close" data-toggle="tooltip" data-offset="0,10" data-original-title="Close"></button>
                    </div>
                </div>
                <div class="panel-container show">
                    <div class="panel-content">
                        <div class="panel-tag">
                            Import <code>Loan</code> Excel Sheeet.
                            <hr/>
                            <form action="<?php echo e(route('import.schdule')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    
                                    <input type="hidden" value="<?php echo e($id); ?>" name="loan_id"/>
                                    <div class="col-md-6">
                                        <label for="excel_file" class="">Select Sheet</label>
                                        <input id="excel_file" type="file" name="excel_file" class="form-control" required autocomplete="excel_file" autofocus>
                                    </div>
                                    <div class="col-md-3">
                                        <button type="submit" class="btn btn-primary mt-4">
                                            Import
                                        </button>
                                    </div>
                                    <div class="col-md-3">
                                        <a download class="btn btn-success mt-4" href="<?php echo e(asset('excel_formates/loan_schedules.xlsx')); ?>">
                                           Sheet Exampe Format
                                        </a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- datatable start -->
                            <table class="table table-bordered table-hover table-striped w-100" id="dt-basic-example">
                                <thead>
                                    <tr>

                                        <th>Principal Payment</th>
                                        <th>Interest Payment</th>
                                        <th>Expected Payment</th>
                                        <th>Expated Payment Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e($item->principal_payment); ?></td>
                                            <td><?php echo e($item->interest_payment); ?></td>
                                            <td><?php echo e($item->expected_payment); ?></td>
                                            <td><?php echo e($item->expected_payment_date); ?></td>
                                            <td>
                                                <?php echo $item->getStatus(); ?>

                                            </td>

                                            <td>
                                                <a href="<?php echo e(route('paid.schdule',$item->id)); ?>" class="btn btn-sm btn-success">Paid</a>
                                                <a href="<?php echo e(route('show.schdule',$item->id)); ?>" class="btn btn-sm btn-primary">View</a>
                                                <a href="<?php echo e(route('edit.schdul',$item->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                                <a href="<?php echo e(route('delete.schdule',$item->id)); ?>" class="btn btn-sm btn-danger">Delete</a>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Principal Payment</th>
                                        <th>Interest Payment</th>
                                        <th>Expected Payment</th>
                                        <th>Expated Payment Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                            </table>
                        <!-- datatable end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\Desktop\Safe Car\new_app\resources\views/director/loan/schdule/manage_schdule.blade.php ENDPATH**/ ?>