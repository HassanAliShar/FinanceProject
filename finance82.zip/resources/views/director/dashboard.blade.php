@extends('home')
@section('pagesection')
<div class="container">
    <div class="subheader">
        <h1 class="subheader-title">
            <i class='subheader-icon fal fa-table'></i> Dashboard
        </h1>
        <a href="" class="btn btn-primary waves-effect waves-themed text-white"><i
                class="fal fa-plus-circle"></i> Create
        </a>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <!-- datatable start -->
                <table class="table table-bordered table-hover table-striped w-100">
                    <thead>
                        <tr>
                            <th>Sno</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Active</th>
                        </tr>
                    </thead>
                    <tbody>
                        {{-- @foreach ($data as $item) --}}

                            <tr>
                                {{-- <td scope="row">{{ $loop->iteration }}</td>
                                <td>{{ $item->vehicle->customer->user->name }}</td>
                                <td>{{ $item->vehicle->customer->user->email }}</td>
                                <td>
                                    <div class="form-group">
                                        <select data-id="{{ $item->id }}" class="form-control" name="status">
                                        @foreach (complainStatus() as $i)
                                            <option {{ ($item->status == $i)?"selected":"" }} value="{{ $i }}">{{ $i }}</option>
                                        @endforeach
                                        </select>
                                    </div>

                                </td>
                                <td>
                                    <a href="{{ url('complains/'.$item->id) }}" class="btn btn-info">View</a>
                                </td> --}}
                            </tr>

                        {{-- @endforeach --}}
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Sno</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Active</th>
                        </tr>
                    </tfoot>
                </table>
                <!-- datatable end -->
            </div>
        </div>
    </div>
</div>
@endsection
