<?php $__env->startSection('pagesection'); ?>
<div class="container">
    <div class="subheader">
        <h1 class="subheader-title">
            <i class='subheader-icon fal fa-table'></i> Manage Loan Schedule
        </h1>
        
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addscheduleModal_1"><i
            class="fal fa-plus-circle"></i>
            Add Loan Schedule
        </button>
    </div>
    <div class="panel-tag mt-5 bg-info">
        <div class="row">
            <div class="col-md-6"><h2 class="text-center" style="color:#fff"> Borrower Name: <span class="text-default"><?php echo e($borrower_name); ?></span></h2></div>
            <div class="col-md-6"><h2 class="text-center" style="color:#fff"> Legal Loan ID: <span class="text-default"><?php echo e($legal_loan_id); ?></span></h2></div>
        </div>
    </div>
    <div class="panel-tag mt-5 shadow">
        <div class="row">
            <div class="col-md-4"><h4> Outstanding Balance: <span class="text-info"><?php echo e(number_format($outstanding_balance,2,',','.')); ?></span></h4></div>
            <div class="col-md-4"><h4> Paid Amount: <span class="text-info"><?php echo e(number_format($schdule,2,',','.')); ?></span></h4></div>
            <div class="col-md-4"><h4> Total Amount: <span class="text-info"><?php echo e(number_format($loan_payment,2,',','.')); ?></span></h4></div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <div class="panel-hdr">
                    <h2>
                        Loan Schedule <span class="fw-300"><i>info</i></span>
                    </h2>
                    <div class="panel-toolbar">
                        <button class="btn btn-panel" data-action="panel-collapse" data-toggle="tooltip" data-offset="0,10" data-original-title="Collapse"></button>
                        <button class="btn btn-panel" data-action="panel-fullscreen" data-toggle="tooltip" data-offset="0,10" data-original-title="Fullscreen"></button>
                        <button class="btn btn-panel" data-action="panel-close" data-toggle="tooltip" data-offset="0,10" data-original-title="Close"></button>
                    </div>
                </div>
                <div class="panel-container show">
                    <div class="panel-content">
                        <div class="panel-tag">
                            Import <code>Loan Schedule</code> Excel Sheet.
                            <hr/>
                            <form action="<?php echo e(route('import.schdule')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <input type="hidden" value="<?php echo e($id); ?>" name="loan_id"/>
                                    <div class="col-md-3">
                                        <label for="excel_file" class="">Select Sheet</label>
                                        <input id="excel_file" type="file" name="excel_file" class="form-control" required autocomplete="excel_file" autofocus>
                                    </div>
                                    <div class="col-md-3">
                                        <button type="submit" class="btn btn-primary mt-4">
                                            Import
                                        </button>
                                    </div>
                                    <div class="col-md-3">
                                        <a download class="btn btn-success mt-4" href="<?php echo e(asset('excel_formates/loan_schdules.xlsx')); ?>">
                                           Sheet Example Format
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a class="btn btn-success mt-4" href="<?php echo e(route('export.schdule',$id)); ?>">
                                            Export Data <i class="fal fa-filter"></i>
                                         </a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- datatable start -->
                            <table class="table table-bordered table-hover table-striped w-100" id="dt-basic-example">
                                <thead>
                                    <tr>

                                        <th>Principal Payment</th>
                                        <th>Interest Payment</th>
                                        <th>Expected Payment</th>
                                        <th>Expected Payment Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <tr>
                                            <td><?php echo e(number_format( $item->principal_payment, 2, ',', '.')); ?></td>
                                            <td><?php echo e(number_format( $item->interest_payment , 2, ',', '.')); ?></td>
                                            <td><?php echo e(number_format( $item->expected_payment , 2, ',', '.')); ?></td>
                                            <td><?php echo e(date('d-m-Y', strtotime( $item->expected_payment_date ))); ?></td>
                                            <td>
                                                <?php echo $item->getStatus(); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('paid.schdule',$item->id)); ?>" class="btn btn-sm btn-success">Paid</a>
                                                <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#viewModal_<?php echo e($item->id); ?>">
                                                    View
                                                </button>
                                                <button type="button" class="btn btn-sm btn-info" data-toggle="modal" data-target="#exampleModal_<?php echo e($item->id); ?>">
                                                    Edit
                                                </button>
                                                <a href="<?php echo e(route('delete.schdule',$item->id)); ?>" class="btn btn-sm btn-danger">Delete</a>

                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Principal Payment</th>
                                        <th>Interest Payment</th>
                                        <th>Expected Payment</th>
                                        <th>Expected Payment Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                            </table>
                        <!-- datatable end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="subheader">
        <h1 class="subheader-title">
            <i class='subheader-icon fal fa-table'></i> Manage Loan Payment
        </h1>
        
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addPaymentModal_1"><i
            class="fal fa-plus-circle"></i>
            Add Loan Payment
        </button>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel">
                <div class="panel-hdr">
                    <h2>
                        Loan Payment <span class="fw-300"><i>info</i></span>
                    </h2>
                    <div class="panel-toolbar">
                        <button class="btn btn-panel" data-action="panel-collapse" data-toggle="tooltip" data-offset="0,10" data-original-title="Collapse"></button>
                        <button class="btn btn-panel" data-action="panel-fullscreen" data-toggle="tooltip" data-offset="0,10" data-original-title="Fullscreen"></button>
                        <button class="btn btn-panel" data-action="panel-close" data-toggle="tooltip" data-offset="0,10" data-original-title="Close"></button>
                    </div>
                </div>
                <div class="panel-container show">
                    <div class="panel-content">
                        <div class="panel-tag">
                            Import <code>Loan Payment</code> Excel Sheet.
                            <hr/>
                            <form action="<?php echo e(route('import.payment')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <input type="hidden" value="<?php echo e($id); ?>" name="loan_id"/>
                                    <div class="col-md-3">
                                        <label for="excel_file" class="">Select Sheet</label>
                                        <input id="excel_file" type="file" name="excel_file" class="form-control" required autocomplete="excel_file" autofocus>
                                    </div>
                                    <div class="col-md-3">
                                        <button type="submit" class="btn btn-primary mt-4">
                                            Import
                                        </button>
                                    </div>
                                    <div class="col-md-3">
                                        <a download class="btn btn-success mt-4" href="<?php echo e(asset('excel_formates/loan_payments.xlsx')); ?>">
                                           Sheet Example Format
                                        </a>
                                    </div>
                                    <div class="col-md-3">
                                        <a class="btn btn-success mt-4" href="<?php echo e(route('export.payment',$id)); ?>">
                                           Export Data <i class="fal fa-filter"></i>
                                        </a>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- datatable start -->
                            <table class="table table-bordered table-hover table-striped w-100" id="dt-basic-example">
                                <thead>
                                    <tr>

                                        <th>Payment Amount</th>
                                        <th>Interest Amount</th>
                                        <th>Payment Date</th>
                                        <th>Payment Note</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data_payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e(number_format( $item->payment_amount, 2, ',', '.')); ?></td>
                                            <td><?php echo e($item->interest_amount); ?></td>
                                            <td><?php echo e(date('d-m-Y', strtotime( $item->payment_date ))); ?></td>
                                            <td><?php echo e($item->payment_note); ?></td>
                                            <td>
                                                
                                                <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#viewPayment_<?php echo e($item->id); ?>">
                                                    View
                                                </button>
                                                <button type="button" class="btn btn-sm btn-info" data-toggle="modal" data-target="#editPayment_<?php echo e($item->id); ?>">
                                                    Edit
                                                </button>
                                                <a href="<?php echo e(route('delete.mg.payment',$item->id)); ?>" class="btn btn-sm btn-danger">Delete</a>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Payment Amount</th>
                                        <th>Interest Amount</th>
                                        <th>Payment Date</th>
                                        <th>Payment Note</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                            </table>
                        <!-- datatable end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


    
    <div class="modal fade" id="addscheduleModal_1" tabindex="-1" role="dialog" aria-labelledby="addscheduleModal" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Schedule</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="<?php echo e(route('store.schdule',$id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="loan_id" value="<?php echo e($id); ?>"/>
                            <div class="form-group row">
                                <label for="principal_payment" class="col-md-4 col-form-label text-md-right">Principle Payment</label>

                                <div class="col-md-6">
                                    <input id="principal_payment" type="text" class="form-control"  placeholder="Principal Payment" name="principal_payment" value="<?php echo e(old('principal_payment')); ?>" required autocomplete="lender_name" autofocus>


                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="interest_payment" class="col-md-4 col-form-label text-md-right">Interest Payment</label>

                                <div class="col-md-6">
                                    <input id="interest_payment" type="text" class="form-control" placeholder="Interest Payment" name="interest_payment" value="<?php echo e(old('interest_payment')); ?>" required autocomplete="interest_payment">

                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="expected_payment" class="col-md-4 col-form-label text-md-right">Expected Payment</label>

                                <div class="col-md-6">
                                    <input id="expected_payment" type="text" class="form-control" placeholder="Expected Payment" name="expected_payment" required autocomplete="identity_type">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="expected_payment_date" class="col-md-4 col-form-label text-md-right">Expected Payment Date</label>

                                <div class="col-md-6">
                                    <input id="expected_payment_date" type="text" class="form-control date" placeholder="DD/MM/YYYY" placeholder="Expected Payment Date" name="expected_payment_date" required autocomplete="expected_payment_date">
                                </div>
                            </div>


                            

                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Data</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    

    
    <div class="modal fade" id="addPaymentModal_1" tabindex="-1" role="dialog" aria-labelledby="addscheduleModal" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Payment</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="<?php echo e(route('store.payment',$id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($id); ?>" name="loan_id"/>
                            <div class="form-group row">
                                <label for="payment_amount" class="col-md-4 col-form-label text-md-right">Amount</label>

                                <div class="col-md-6">
                                    <input id="payment_amount" type="text" class="form-control" placeholder="Payment Amount" name="payment_amount" value="<?php echo e(old('payment_amount')); ?>" required autocomplete="lender_name" autofocus>


                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="interest_amount" class="col-md-4 col-form-label text-md-right">Interest Amount</label>

                                <div class="col-md-6">
                                    <input id="interest_amount" type="text" class="form-control" placeholder="Payment Interest Amount" name="interest_amount" value="<?php echo e(old('interest_amount')); ?>" required autocomplete="interest_amount" autofocus>


                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="payment_date" class="col-md-4 col-form-label text-md-right">Payment Date</label>

                                <div class="col-md-6">
                                    <input id="payment_date" type="text" class="form-control date" placeholder="DD/MM/YYYY" placeholder="Payment Date" name="payment_date" required autocomplete="payment_date">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="payment_note" class="col-md-4 col-form-label text-md-right">Payment Note</label>

                                <div class="col-md-6">
                                    <input id="payment_note" type="text" class="form-control" placeholder="Payment Note" name="payment_note" required autocomplete="payment_note">
                                </div>
                            </div>

                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Data</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    

  <!-- Schdule Modal Start Here -->
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="exampleModal_<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edit Schedule</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        </div>
                        <div class="modal-body">
                            <form method="POST" action="<?php echo e(route('update.schdule',$row->id)); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="loan_id" value="<?php echo e($row->loan_id); ?>"/>
                                <div class="form-group row">
                                    <label for="principal_payment" class="col-md-4 col-form-label text-md-right">Principle Payment</label>

                                    <div class="col-md-6">
                                        <input id="principal_payment" type="text" class="form-control" value="<?php echo e($row->principal_payment); ?>" placeholder="Principal Payment" name="principal_payment" value="<?php echo e(old('principal_payment')); ?>" required autocomplete="lender_name" autofocus>


                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="interest_payment" class="col-md-4 col-form-label text-md-right">Interest Payment</label>

                                    <div class="col-md-6">
                                        <input id="interest_payment" type="text" class="form-control" value="<?php echo e($row->interest_payment); ?>" placeholder="Interest Payment" name="interest_payment" value="<?php echo e(old('interest_payment')); ?>" required autocomplete="interest_payment">

                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="expected_payment" class="col-md-4 col-form-label text-md-right">Expected Payment</label>

                                    <div class="col-md-6">
                                        <input id="expected_payment" type="text" class="form-control" value="<?php echo e($row->expected_payment); ?>" placeholder="Expected Payment" name="expected_payment" required autocomplete="identity_type">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="expected_payment_date" class="col-md-4 col-form-label text-md-right">Expected Payment Date</label>

                                    <div class="col-md-6">
                                        <input id="expected_payment_date" type="text" class="form-control date" placeholder="DD/MM/YYYY" value="<?php echo e(date('d-m-Y', strtotime($row->expected_payment_date))); ?>" placeholder="Expected Payment Date" name="expected_payment_date" required autocomplete="expected_payment_date">
                                    </div>
                                </div>


                                

                        </div>
                        <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update Schedule</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="modal fade" id="viewModal_<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">View Schedule</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <div class="modal-body">
                        <form>
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="principal_payment" class="col-md-4 col-form-label text-md-right">Principle Payment</label>

                                <div class="col-md-6">
                                    <input id="principal_payment" type="text" readonly class="form-control" value="<?php echo e($row->principal_payment); ?>" placeholder="Principal Payment" name="principal_payment" value="<?php echo e(old('principal_payment')); ?>" required autocomplete="lender_name" autofocus>


                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="interest_payment" class="col-md-4 col-form-label text-md-right">Interest Payment</label>

                                <div class="col-md-6">
                                    <input id="interest_payment" type="text" readonly class="form-control" value="<?php echo e($row->interest_payment); ?>" placeholder="Interest Payment" name="interest_payment" value="<?php echo e(old('interest_payment')); ?>" required autocomplete="interest_payment">

                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="expected_payment" class="col-md-4 col-form-label text-md-right">Expected Payment</label>

                                <div class="col-md-6">
                                    <input id="expected_payment" type="text" readonly class="form-control" value="<?php echo e($row->expected_payment); ?>" placeholder="Expected Payment" name="expected_payment" required autocomplete="identity_type">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="expected_payment_date" class="col-md-4 col-form-label text-md-right">Expected Payment Date</label>

                                <div class="col-md-6">
                                    <input id="expected_payment_date" type="text" readonly class="form-control date" value="<?php echo e(date('d-m-Y', strtotime( $row->expected_payment_date ))); ?>" placeholder="Expected Payment Date" name="expected_payment_date" required autocomplete="expected_payment_date">
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
        <?php $__currentLoopData = $data_payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="editPayment_<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                            <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Edit Payment</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                            <div class="modal-body">
                                <form method="POST" action="<?php echo e(route('update.payment',$row->id)); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="<?php echo e($row->loan_id); ?>" name="loan_id"/>
                                    <div class="form-group row">
                                        <label for="payment_amount" class="col-md-4 col-form-label text-md-right">Amount</label>

                                        <div class="col-md-6">
                                            <input id="payment_amount" type="text" class="form-control" value="<?php echo e($row->payment_amount); ?>" placeholder="Payment Amount" name="payment_amount" value="<?php echo e(old('payment_amount')); ?>" required autocomplete="lender_name" autofocus>


                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="interest_amount" class="col-md-4 col-form-label text-md-right">Interest Amount</label>

                                        <div class="col-md-6">
                                            <input id="interest_amount" type="text" class="form-control" value="<?php echo e($row->interest_amount); ?>" placeholder="Payment Interest Amount" name="interest_amount" value="<?php echo e(old('interest_amount')); ?>" required autocomplete="interest_amount" autofocus>


                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="payment_date" class="col-md-4 col-form-label text-md-right">Payment Date</label>

                                        <div class="col-md-6">
                                            <input id="payment_date" type="text" class="form-control date" placeholder="DD/MM/YYYY" value="<?php echo e(date('d-m-Y', strtotime($row->payment_date))); ?>" placeholder="Payment Date" name="payment_date" required autocomplete="payment_date">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="payment_note" class="col-md-4 col-form-label text-md-right">Payment Note</label>

                                        <div class="col-md-6">
                                            <input id="payment_note" type="text" class="form-control" value="<?php echo e($row->payment_note); ?>" placeholder="Payment Note" name="payment_note" required autocomplete="payment_note">
                                        </div>
                                    </div>

                                    
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Update Payment</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="viewPayment_<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">View Payment</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        </div>
                        <div class="modal-body">
                            <form >
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label for="payment_amount" class="col-md-4 col-form-label text-md-right">Amount</label>

                                    <div class="col-md-6">
                                        <input id="payment_amount" readonly  type="text" class="form-control" value="<?php echo e($row->payment_amount); ?>" placeholder="Payment Amount" name="payment_amount" value="<?php echo e(old('payment_amount')); ?>" required autocomplete="lender_name" autofocus>

                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="interest_amount" class="col-md-4 col-form-label text-md-right">Interest Amount</label>

                                    <div class="col-md-6">
                                        <input id="interest_amount" readonly  type="text" class="form-control" value="<?php echo e($row->interest_amount); ?>" placeholder="Payment Interest Amount" name="interest_amount" value="<?php echo e(old('interest_amount')); ?>" required autocomplete="interest_amount" autofocus>

                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="payment_date" class="col-md-4 col-form-label text-md-right">Payment Date</label>

                                    <div class="col-md-6">
                                        <input id="payment_date" readonly type="text" class="form-control date" placeholder="DD/MM/YYYY" value="<?php echo e(date('d-m-Y', strtotime($row->payment_date))); ?>" placeholder="Payment Date" name="payment_date" required autocomplete="payment_date">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="payment_note" class="col-md-4 col-form-label text-md-right">Payment Note</label>

                                    <div class="col-md-6">
                                        <input id="payment_note" readonly type="text" class="form-control" value="<?php echo e($row->payment_note); ?>" placeholder="Payment Note" name="payment_note" required autocomplete="payment_note">
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\Desktop\Safe Car\new_app\resources\views/director/loan/schdule/manage_schdule.blade.php ENDPATH**/ ?>